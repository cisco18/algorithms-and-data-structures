package com.company;



public class Main {

    public static void main(String[] args) {
        Operations operations = new Operations();
        Worker[] workerS = operations.readFromFile("workers.txt");
        operations.addWorkers(workerS);
        operations.showWorkersList(workerS);
        operations.writeToFile(workerS);

    }
}
